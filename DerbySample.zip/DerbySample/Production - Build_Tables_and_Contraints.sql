## DROP Databses 
DROP DATABASE IF EXISTS Project_DB;

## Build Databases
CREATE DATABASE Project_DB;

## Bould project tables
CREATE TABLE Employees
(
  	employee_id int(9) PRIMARY KEY,
  	first_name varchar(20) NOT NULL,
	last_name varchar(20) NOT NULL,
	city varchar(20) NOT NULL, #used to determine tax-discount regions
	address varchar(30),
	email varchar (30),

); 

CREATE TABLE Salaries
(
	employee_id int(9),
	salary int(8),
	date date,

);

insert into Employees (employee_id,first_name,last_name,city,address,email) VALUES(307429680,'alex','smoly','Tel Aviv', 'Ziatli 24', 'amigo123@yahoo.com');